# Jira-to-Github
Convert Jira ticket title to fit Github